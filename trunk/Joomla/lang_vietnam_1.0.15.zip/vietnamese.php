<?php
/**
* @version $Id: vietnam.php 4004 2006-06-12 17:44:14Z stingrey $
* @package Joomla
* @copyright Copyright (C) 2005 Open Source Matters. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

// Site page note found
define( '_404', 'Rất tiếc, trang mà bạn yêu cầu không tồn tại.' );
define( '_404_RTS', 'Trở lại website' );

DEFINE( '_SYSERR1', 'Không tìm thấy database adapter' );
DEFINE( '_SYSERR2', 'Không thể kết nối tới máy chủ CSDL' );
DEFINE( '_SYSERR3', 'Không thể kết nối tới CSDL' );

// common
DEFINE('_LANGUAGE','vn');
DEFINE('_NOT_AUTH','Bạn không có đủ quyền truy cập khu vực này.');
DEFINE('_DO_LOGIN','Bạn phải đăng nhập.');
DEFINE('_VALID_AZ09',"Hãy nhập %s hợp lệ.  Không dấu cách, nhiều hơn %d kí tự và chứa 0-9,a-z,A-Z");
DEFINE('_VALID_AZ09_USER',"Vui lòng nhập %s hợp lệ. Nhiều hơn %d ký tự và chỉ bao gồm 0-9,a-z,A-Z");
DEFINE('_CMN_YES','Có');
DEFINE('_CMN_NO','Không');
DEFINE('_CMN_SHOW','Hiện');
DEFINE('_CMN_HIDE','Ẩn');

DEFINE('_CMN_NAME','Tên');
DEFINE('_CMN_DESCRIPTION','Miêu tả');
DEFINE('_CMN_SAVE','Lưu');
DEFINE('_CMN_APPLY','Chấp nhận');
DEFINE('_CMN_CANCEL','Thôi');
DEFINE('_CMN_PRINT','In');
DEFINE('_CMN_PDF','PDF');
DEFINE('_CMN_EMAIL','E-mail');
DEFINE('_ICON_SEP','|');
DEFINE('_CMN_PARENT','Cấp trên');
DEFINE('_CMN_ORDERING','Thứ tự');
DEFINE('_CMN_ACCESS','Cấp độ truy cập');
DEFINE('_CMN_SELECT','Chọn');

DEFINE('_CMN_NEXT','Tiếp');
DEFINE('_CMN_NEXT_ARROW'," &gt;&gt;");
DEFINE('_CMN_PREV','Trước');
DEFINE('_CMN_PREV_ARROW',"&lt;&lt; ");

DEFINE('_CMN_SORT_NONE','Không sắp xếp');
DEFINE('_CMN_SORT_ASC','Tăng dần');
DEFINE('_CMN_SORT_DESC','Giảm dần');

DEFINE('_CMN_NEW','Mới');
DEFINE('_CMN_NONE','Không');
DEFINE('_CMN_LEFT','Trái');
DEFINE('_CMN_RIGHT','Phải');
DEFINE('_CMN_CENTER','Giữa');
DEFINE('_CMN_ARCHIVE','Lưu trữ');
DEFINE('_CMN_UNARCHIVE','Không lưu trữ');
DEFINE('_CMN_TOP','Đầu');
DEFINE('_CMN_BOTTOM','Cuối');

DEFINE('_CMN_PUBLISHED','Công bố');
DEFINE('_CMN_UNPUBLISHED','Không công bố');

DEFINE('_CMN_EDIT_HTML','Soạn HTML');
DEFINE('_CMN_EDIT_CSS','Soạn CSS');

DEFINE('_CMN_DELETE','Xoá');

DEFINE('_CMN_FOLDER','Thư mục');
DEFINE('_CMN_SUBFOLDER','Thư mục con');
DEFINE('_CMN_OPTIONAL','Tuỳ chọn');
DEFINE('_CMN_REQUIRED','Bắt buộc');

DEFINE('_CMN_CONTINUE','Tiếp tục');

DEFINE('_STATIC_CONTENT','Nội dung tĩnh');

DEFINE('_CMN_NEW_ITEM_LAST','Mục mới nằm ở vị trí cuối cùng theo mặc định. Thứ tự có thể thay đổi sau khi lưu lại mục này.');
DEFINE('_CMN_NEW_ITEM_FIRST','Mục mới nằm ở vị trí đầu tiên theo mặc định. Thứ tự có thể thay đổi sau khi lưu lại mục này.');
DEFINE('_LOGIN_INCOMPLETE','Hãy điền đủ tên đăng nhập và mật khẩu vào các ô.');
DEFINE('_LOGIN_BLOCKED','Bạn bị cấm đăng nhập. Hãy liên lạc với người quản trị.');
DEFINE('_LOGIN_INCORRECT','Sai mật khẩu hoặc tên người dùng. Xin hãy thử lại.');
DEFINE('_LOGIN_NOADMINS','Bạn không thể đăng nhập. Không có thiết lập quản trị nào.');
DEFINE('_CMN_JAVASCRIPT','!Cảnh báo! Javascript phải được cho phép để mọi thứ hoạt động tốt.');

DEFINE('_NEW_MESSAGE','Có một tin nhắn riêng');
DEFINE('_MESSAGE_FAILED','Người dùng đã khoá hòm thư của họ. Không gửi được tin nhắn.');

DEFINE('_CMN_IFRAMES', 'Tuỳ chọn này sẽ không hoạt động chính xác. Thật không may, trình duyệt của bạn không hỗ trợ khung nội tuyến (Inline Frames)');

DEFINE('_INSTALL_3PD_WARN','Cảnh báo: Việc cài đặt các phần mở rộng có thể làm ảnh hưởng tới tính bảo mật trang web của bạn. Việc nâng cấp Joomla! sẽ không bao gồm nâng cấp các thành phần mở rộng.<br />Để có thêm thông tin trong việc bảo mật trang web của bạn, hãy vào <a href="http://forum.joomla.org/index.php/board,267.0.html" target="_blank" style="color: blue; text-decoration: underline;">Diễn đàn bảo mật của Joomla!</a>.');
DEFINE('_INSTALL_WARN','Vì lí do bảo mật cho bạn, hãy xoá toàn bộ thư mục cài đặt (bao gồm cả các tập tin và thư mục con) rồi tải lại trang này');
DEFINE('_TEMPLATE_WARN','<font color=\"red\"><b>Không tìm thấy tập tin mẫu giao diện! Đang tìm mẫu:</b></font>');
DEFINE('_NO_PARAMS','Không có tham số cho mục này');
DEFINE('_HANDLER','Kiểu file không xác định');

/** mambots */
DEFINE('_TOC_JUMPTO','Mục lục bài viết');

/**  content */
DEFINE('_READ_MORE','Đọc tiếp...');
DEFINE('_READ_MORE_REGISTER','Đăng kí để đọc tiếp...');
DEFINE('_MORE','Các bài khác...');
DEFINE('_ON_NEW_CONTENT', "Một thông tin được [ %s ] gửi với tiêu đề [ %s ] từ phần [ %s ] và chuyên mục  [ %s ]" );
DEFINE('_SEL_CATEGORY','- Chọn Chuyên mục -');
DEFINE('_SEL_SECTION','- Chọn Phần -');
DEFINE('_SEL_AUTHOR','- Chọn Tác giả -');
DEFINE('_SEL_POSITION','- Chọn Vị trí -');
DEFINE('_SEL_TYPE','- Chọn Kiểu -');
DEFINE('_EMPTY_CATEGORY','Chuyên mục này hiện tại bị bỏ trống');
DEFINE('_EMPTY_BLOG','Chưa có bài viết nào');
DEFINE('_NOT_EXIST','Trang mà bạn đang muốn truy cập không tồn tại.<br />Hãy chọn một trang khác từ mục lục.');
DEFINE('_SUBMIT_BUTTON','Gửi');

/** classes/html/modules.php */
DEFINE('_BUTTON_VOTE','Bỏ phiếu');
DEFINE('_BUTTON_RESULTS','Kết quả');
DEFINE('_USERNAME','Tên người dùng');
DEFINE('_LOST_PASSWORD','Bạn quên mật khẩu?');
DEFINE('_PASSWORD','Mật khẩu');
DEFINE('_BUTTON_LOGIN','Đăng nhập');
DEFINE('_BUTTON_LOGOUT','Đăng xuất');
DEFINE('_NO_ACCOUNT','Chưa có tài khoản?');
DEFINE('_CREATE_ACCOUNT','Tạo một tài khoản');
DEFINE('_VOTE_POOR','Nghèo nàn');
DEFINE('_VOTE_BEST','Tốt nhất');
DEFINE('_USER_RATING','Bầu chọn của người dùng');
DEFINE('_RATE_BUTTON','Mức độ');
DEFINE('_REMEMBER_ME','Lưu thông tin');

/** contact.php */
DEFINE('_ENQUIRY','Thăm hỏi');
DEFINE('_ENQUIRY_TEXT','Đây là một thư điện tử được gửi qua %s từ:');
DEFINE('_COPY_TEXT','Đây là một bản sao của nội dung thư điện tử mà bạn đã gửi tới %s qua %s ');
DEFINE('_COPY_SUBJECT','Bản sao của: ');
DEFINE('_THANK_MESSAGE','Cảm ơn về e-mail của bạn');
DEFINE('_CLOAKING','Địa chỉ email này đang được bảo vệ khỏi chương trình thư rác, bạn cần bật Javascript để xem nó');
DEFINE('_CONTACT_HEADER_NAME','Tên');
DEFINE('_CONTACT_HEADER_POS','Vị trí');
DEFINE('_CONTACT_HEADER_EMAIL','Email');
DEFINE('_CONTACT_HEADER_PHONE','Điện thoại');
DEFINE('_CONTACT_HEADER_FAX','Fax');
DEFINE('_CONTACTS_DESC','Danh sách Liên lạc cho website này.');
DEFINE('_CONTACT_MORE_THAN','Bạn không thể nhập nhiều hơn 1 địa chỉ email.');

/** classes/html/contact.php */
DEFINE('_CONTACT_TITLE','Liên lạc');
DEFINE('_EMAIL_DESCRIPTION','Gửi một email tới đầu mối liên lạc này:');
DEFINE('_NAME_PROMPT',' Nhập tên của bạn:');
DEFINE('_EMAIL_PROMPT',' Địa chỉ email:');
DEFINE('_MESSAGE_PROMPT',' Tin nhắn của bạn:');
DEFINE('_SEND_BUTTON','Gửi');
DEFINE('_CONTACT_FORM_NC','Hãy đảm bảo là mẫu gửi thư này đã được điền đúng.');
DEFINE('_CONTACT_TELEPHONE','Điện thoại: ');
DEFINE('_CONTACT_MOBILE','Điện thoại di động: ');
DEFINE('_CONTACT_FAX','Fax: ');
DEFINE('_CONTACT_EMAIL','Email: ');
DEFINE('_CONTACT_NAME','Tên: ');
DEFINE('_CONTACT_POSITION','Vị trí: ');
DEFINE('_CONTACT_ADDRESS','Địa chỉ: ');
DEFINE('_CONTACT_MISC','Thông tin: ');
DEFINE('_CONTACT_SEL','Chọn Liên lạc:');
DEFINE('_CONTACT_NONE','Không có địa chỉ liên lạc nào được cung cấp.');
DEFINE('_CONTACT_ONE_EMAIL','Bạn không thể nhập nhiều hơn 1 địa chỉ email.');
DEFINE('_EMAIL_A_COPY','Gửi email một bản sao của tin nhắn này tới địa chỉ của chính bạn');
DEFINE('_CONTACT_DOWNLOAD_AS','Tải thông tin về ở dạng');
DEFINE('_VCARD','VCard');

/** pageNavigation */
DEFINE('_PN_LT','&lt;');
DEFINE('_PN_RT','&gt;');
DEFINE('_PN_PAGE','Trang');
DEFINE('_PN_OF','/');
DEFINE('_PN_START','Bắt đầu');
DEFINE('_PN_PREVIOUS','Trước');
DEFINE('_PN_NEXT','Tiếp');
DEFINE('_PN_END','Cuối');
DEFINE('_PN_DISPLAY_NR','Hiển thị #');
DEFINE('_PN_RESULTS','Kết quả');

/** emailfriend */
DEFINE('_EMAIL_TITLE','Gửi email cho người khác');
DEFINE('_EMAIL_FRIEND','Gửi email cho người khác.');
DEFINE('_EMAIL_FRIEND_ADDR',"Email của người bạn muốn gửi:");
DEFINE('_EMAIL_YOUR_NAME','Tên của bạn:');
DEFINE('_EMAIL_YOUR_MAIL','Email của bạn:');
DEFINE('_SUBJECT_PROMPT',' Tiêu đề tin nhắn:');
DEFINE('_BUTTON_SUBMIT_MAIL','Gửi email');
DEFINE('_BUTTON_CANCEL','Thôi');
DEFINE('_EMAIL_ERR_NOINFO','Bạn phải nhập địa chỉ email hợp lệ.');
DEFINE('_EMAIL_MSG',' Trang sau từ website "%s" đã được %s ( %s ) gửi tới bạn.

Bạn có thể truy cập theo địa chỉ:
%s');
DEFINE('_EMAIL_INFO','Người gửi');
DEFINE('_EMAIL_SENT','Mục này đã được gửi tới');
DEFINE('_PROMPT_CLOSE','Đóng cửa sổ');

/** classes/html/content.php */
DEFINE('_AUTHOR_BY', ' Đóng góp của');
DEFINE('_WRITTEN_BY', ' Người viết: ');
DEFINE('_LAST_UPDATED', 'Cập nhật');
DEFINE('_BACK','[ Quay lại ]');
DEFINE('_LEGEND','Nhãn');
DEFINE('_DATE','Ngày');
DEFINE('_ORDER_DROPDOWN','Thứ tự');
DEFINE('_HEADER_TITLE','Tiêu đề của bài');
DEFINE('_HEADER_AUTHOR','Tác giả');
DEFINE('_HEADER_SUBMITTED','Đã gửi');
DEFINE('_HEADER_HITS','Xem');
DEFINE('_E_EDIT','Soạn');
DEFINE('_E_ADD','Thêm');
DEFINE('_E_WARNUSER','Hãy hoặc là Bỏ qua hoặc Lưu lại các thay đổi hiện tại');
DEFINE('_E_WARNTITLE','Phải đặt tiêu đề cho bài viết');
DEFINE('_E_WARNTEXT','Bài viết phải có phần giới thiệu');
DEFINE('_E_WARNCAT','Hãy chọn một chuyên mục');
DEFINE('_E_CONTENT','Nội dung');
DEFINE('_E_TITLE','Tiêu đề:');
DEFINE('_E_CATEGORY','Chuyên mục:');
DEFINE('_E_INTRO','Phần giới thiệu');
DEFINE('_E_MAIN','Nội dung chính');
DEFINE('_E_MOSIMAGE','Chèn {mosimage}');
DEFINE('_E_IMAGES','Hình ảnh');
DEFINE('_E_GALLERY_IMAGES','Trưng bày hình ảnh');
DEFINE('_E_CONTENT_IMAGES','Minh hoạ nội dung');
DEFINE('_E_EDIT_IMAGE','Sửa ảnh');
DEFINE('_E_NO_IMAGE','Không có hình');
DEFINE('_E_INSERT','Chèn');
DEFINE('_E_UP','Lên');
DEFINE('_E_DOWN','Xuống');
DEFINE('_E_REMOVE','Xoá bỏ');
DEFINE('_E_SOURCE','Nguồn:');
DEFINE('_E_ALIGN','Canh lề:');
DEFINE('_E_ALT','Văn bản thay thế:');
DEFINE('_E_BORDER','Viền:');
DEFINE('_E_CAPTION','Tiêu đề');
DEFINE('_E_CAPTION_POSITION','Vị trí tiêu đề');
DEFINE('_E_CAPTION_ALIGN','Canh hàng tiêu đề');
DEFINE('_E_CAPTION_WIDTH','Độ rộng tiêu đề');
DEFINE('_E_APPLY','Áp dụng');
DEFINE('_E_PUBLISHING','Xuất bản');
DEFINE('_E_STATE','Trạng thái:');
DEFINE('_E_AUTHOR_ALIAS','Bí danh tác giả:');
DEFINE('_E_ACCESS_LEVEL','Cấp độ truy cập:');
DEFINE('_E_ORDERING','Thứ tự:');
DEFINE('_E_START_PUB','Bắt đầu xuất bản:');
DEFINE('_E_FINISH_PUB','Hoàn tất xuất bản:');
DEFINE('_E_SHOW_FP','Hiện trên Trang đầu:');
DEFINE('_E_HIDE_TITLE','Ẩn tiêu đề bài viết:');
DEFINE('_E_METADATA','Siêu dữ liệu');
DEFINE('_E_M_DESC','Miêu tả:');
DEFINE('_E_M_KEY','Từ khoá:');
DEFINE('_E_SUBJECT','Tiêu đề:');
DEFINE('_E_EXPIRES','Ngày hết hạn:');
DEFINE('_E_VERSION','Phiên bản:');
DEFINE('_E_ABOUT','Giới thiệu');
DEFINE('_E_CREATED','Tạo:');
DEFINE('_E_LAST_MOD','Lần sửa cuối:');
DEFINE('_E_HITS','Số lần xem:');
DEFINE('_E_SAVE','Lưu');
DEFINE('_E_CANCEL','Thôi');
DEFINE('_E_REGISTERED','Chỉ người dùng đã đăng kí');
DEFINE('_E_ITEM_INFO','Thông tin về bài');
DEFINE('_E_ITEM_SAVED','Đã lưu bài thành công.');
DEFINE('_ITEM_PREVIOUS','&lt; Trước');
DEFINE('_ITEM_NEXT','Tiếp &gt;');
DEFINE('_KEY_NOT_FOUND','Không tìm thấy từ khóa trên');


/** content.php */
DEFINE('_SECTION_ARCHIVE_EMPTY','Hiện tại chưa có bản lưu trữ nào trong phần này, xin hãy quay lại sau');
DEFINE('_CATEGORY_ARCHIVE_EMPTY','Hiện tại chưa có bản lưu trữ nào trong chuyên mục này, xin hãy quay lại sau');
DEFINE('_HEADER_SECTION_ARCHIVE','Lưu trữ cho phần');
DEFINE('_HEADER_CATEGORY_ARCHIVE','Lưu trữ cho chuyên mục');
DEFINE('_ARCHIVE_SEARCH_FAILURE','Chưa có bản lưu trữ nào cho %s %s');	// values are month then year
DEFINE('_ARCHIVE_SEARCH_SUCCESS','Đây là các bản lưu trữ cho %s %s');	// values are month then year
DEFINE('_FILTER','Lọc');
DEFINE('_ORDER_DROPDOWN_DA','Ngày, tăng dần');
DEFINE('_ORDER_DROPDOWN_DD','Ngày, giảm dần');
DEFINE('_ORDER_DROPDOWN_TA','Tiêu đề, tăng dần');
DEFINE('_ORDER_DROPDOWN_TD','Tiêu đề, giảm dần');
DEFINE('_ORDER_DROPDOWN_HA','Lần xem, tăng dần');
DEFINE('_ORDER_DROPDOWN_HD','Lần xem, giảm dần');
DEFINE('_ORDER_DROPDOWN_AUA','Tác giả, tăng dần');
DEFINE('_ORDER_DROPDOWN_AUD','Tác giả, giảm dần');
DEFINE('_ORDER_DROPDOWN_O','Thứ tự');

/** poll.php */
DEFINE('_ALERT_ENABLED','Phải bật cookie!');
DEFINE('_ALREADY_VOTE','Hôm nay bạn đã bỏ phiếu cho cuộc bình chọn này rồi!');
DEFINE('_NO_SELECTION','Chưa chọn phần nào, hãy thử lại');
DEFINE('_THANKS','Cảm ơn bạn đã cho ý kiến!');
DEFINE('_SELECT_POLL','Chọn cuộc bình chọn từ danh sách');

/** classes/html/poll.php */
DEFINE('_JAN','Tháng 1');
DEFINE('_FEB','Tháng 2');
DEFINE('_MAR','Tháng 3');
DEFINE('_APR','Tháng 4');
DEFINE('_MAY','Tháng 5');
DEFINE('_JUN','Tháng 6');
DEFINE('_JUL','Tháng 7');
DEFINE('_AUG','Tháng 8');
DEFINE('_SEP','Tháng 9');
DEFINE('_OCT','Tháng 10');
DEFINE('_NOV','Tháng 11');
DEFINE('_DEC','Tháng 12');
DEFINE('_POLL_TITLE','Bình chọn - Kết quả');
DEFINE('_SURVEY_TITLE','Tên cuộc bình chọn:');
DEFINE('_NUM_VOTERS','Số người bỏ phiếu');
DEFINE('_FIRST_VOTE','Phiếu đầu tiên');
DEFINE('_LAST_VOTE','Phiếu cuối cùng');
DEFINE('_SEL_POLL','Chọn cuộc bình chọn:');
DEFINE('_NO_RESULTS','Không có kết quả nào cho cuộc bình chọn này.');

/** registration.php */
DEFINE('_ERROR_PASS','Rất tiếc, không có người dùng nào như vậy');
DEFINE('_NEWPASS_MSG','Tài khoản người dùng $checkusername có email liên quan.\n'
.'Một người dùng từ $mosConfig_live_site vừa yêu cầu gửi một mật khẩu mới.\n\n'
.' Mật khẩu mới của bạn là: $newpass\n\nNếu bạn không yêu cầu gửi mật khẩu thì cũng đừng lo lắng.'
.' Nếu có vấn đề nào đó thì hãy dùng mật khẩu mới này để đăng nhập'
.' rồi thay đổi mật khẩu.');
DEFINE('_NEWPASS_SUB','$_sitename :: Mật khẩu mới cho - $checkusername');
DEFINE('_NEWPASS_SENT','Mật khẩu mới đã được tạo và gửi đi!');
DEFINE('_REGWARN_NAME','Hãy nhập tên của bạn.');
DEFINE('_REGWARN_UNAME','Hãy nhập tên người dùng của bạn.');
DEFINE('_REGWARN_MAIL','Hãy nhập một địa chỉ email hợp lệ.');
DEFINE('_REGWARN_PASS','Hãy nhập một mật khẩu hợp lệ. Không dấu cách, nhiều hơn 6 kí tự và nằm trong khoảng 0-9,a-z,A-Z');
DEFINE('_REGWARN_VPASS1','Hãy xác nhận mật khẩu.');
DEFINE('_REGWARN_VPASS2','Mật khẩu và phần xác nhận không khớp nhau, xin hãy thử lại.');
DEFINE('_REGWARN_INUSE','Tên người dùng/mật khẩu này đã được dùng. Hãy chọn tên khác.');
DEFINE('_REGWARN_EMAIL_INUSE', 'Email này đã được đăng kí. Nếu bạn quên mật khẩu thì hãy nhấn vào "Bạn mất mật khẩu?" và một mật khẩu mới sẽ được gửi cho bạn.');
DEFINE('_SEND_SUB','Thông tin tài khoản của %s tại %s');
DEFINE('_USEND_MSG_ACTIVATE', 'Xin chào %s,

Cảm ơn bạn đã đăng kí vào %s. Tài khoản của bạn đã được tạo và phải được kích hoạt trước khi bạn có thể sử dụng.
Để kích hoạt tài khoản, hãy nhấn vào liên kết dưới đây hoặc chép-dán vào trình duyệt của bạn:
%s

Sau khi kích hoạt, bạn có để đăng nhập vào %s bằng tên người dùng và mật khẩu dưới đây:

Tên người dùng - %s
Mật khẩu - %s');
DEFINE('_USEND_MSG', "Xin chào %s,

Cảm ơn bạn đã đăng kí vào %s.

Bạn có thể đăng nhập vào %s bằng tên người dùng và mật khẩu mà bạn đã đăng kí.");
DEFINE('_USEND_MSG_NOPASS','Xin chào $name,\n\nBạn đã được đưa vào danh sách người dùng tại $mosConfig_live_site.\n'
.'Bạn có thể đang nhập vào $mosConfig_live_site với tên người dùng và mật khẩu mà bạn đã đăng kí.\n\n'
.'Xin đừng trả lời thư này vì nó được tự động tạo ra duy nhất vì mục đích thông tin\n');
DEFINE('_ASEND_MSG','Xin chào %s,

Một người dùng mới đã đăng kí vào %s.
Email này có thông tin về họ:

Tên - %s
e-mail - %s
Tên người dùng - %s

Xin đừng trả lời thư này vì nó được tự động tạo ra duy nhất vì mục đích thông tin');
DEFINE('_REG_COMPLETE_NOPASS','<div class="componentheading">Đăng kí hoàn tất!</div><br />&nbsp;&nbsp;'
.'Bây giờ bạn có thể đăng nhập.<br />&nbsp;&nbsp;');
DEFINE('_REG_COMPLETE', '<div class="componentheading">Đăng kí hoàn tất!</div><br />Bây giờ bạn có thể đăng nhập.');
DEFINE('_REG_COMPLETE_ACTIVATE', '<div class="componentheading">Đăng kí hoàn tất!</div><br />Tài khoản của bạn đã được tạo và liên kết để kích hoạt đã được gửi tới địa chỉ email mà bạn vừa cung cấp. Chú ý là trước khi có thể đăng nhập thì bạn phải kích hoạt tài khoản bằng cách nhấn vào liên kết kích hoạt khi bạn nhận được email.');
DEFINE('_REG_ACTIVATE_COMPLETE', '<div class="componentheading">Đăng kí hoàn tất!</div><br />Tài khoản của bạn đã được kích hoạt thành công. Bây giờ bạn có thể đăng nhập với tên người dùng và mật khẩu mà bạn đã đăng kí.');
DEFINE('_REG_ACTIVATE_NOT_FOUND', '<div class="componentheading">Liên kết kích hoạt không hợp lệ!</div><br />Không có tài khoản nào như vậy trong cơ sở dữ liệu của chúng tôi hoặc là tài khoản này đã được kích hoạt.');
DEFINE('_REG_ACTIVATE_FAILURE', '<div class="componentheading">Quá trình kích hoạt không thành công!</div><br />Hệ thống không thể kích hoạt tài khoản cho bạn, vui lòng liên hệ với quản trị website.');

/** classes/html/registration.php */
DEFINE('_PROMPT_PASSWORD','Bạn mất mật khẩu?');
DEFINE('_NEW_PASS_DESC','Hãy nhập Tên người dùng và địa chỉ email rồi nhấn vào nút <b>Gửi mật khẩu</b>.<br />'
.'Bạn sẽ sớm nhận được mật khẩu. Hãy dùng mật khẩu đó để đăng nhập.<br />&nbsp;<br />');
DEFINE('_PROMPT_UNAME','Tên người dùng:');
DEFINE('_PROMPT_EMAIL','Địa chỉ email:');
DEFINE('_BUTTON_SEND_PASS','Gửi mật khẩu');
DEFINE('_REGISTER_TITLE','Đăng kí');
DEFINE('_REGISTER_NAME','Họ tên:');
DEFINE('_REGISTER_UNAME','Tên người dùng:');
DEFINE('_REGISTER_EMAIL','Email:');
DEFINE('_REGISTER_PASS','Mật khẩu:');
DEFINE('_REGISTER_VPASS','Xác nhận mật khẩu:');
DEFINE('_REGISTER_REQUIRED','Bắt buộc phải điền vào các ô có đánh dấu hoa thị (*).');
DEFINE('_BUTTON_SEND_REG','Gửi bản đăng kí');
DEFINE('_SENDING_PASSWORD','Mật khẩu của bạn sẽ được gửi vào địa chỉ email trên.<br />
.Khi đã nhận được mật khẩu mới bạn có thể đăng nhập và đổi lại.');

/** classes/html/search.php */
DEFINE('_SEARCH_TITLE','Tìm kiếm');
DEFINE('_PROMPT_KEYWORD','Tìm từ khoá');
DEFINE('_SEARCH_MATCHES','trả lại %d kết quả');
DEFINE('_CONCLUSION','Tổng cộng $totalRows kết quả được tìm thấy. Tìm <b>$searchword</b> với');
DEFINE('_NOKEYWORD','Không có kết quả nào');
DEFINE('_IGNOREKEYWORD','Một hoặc một số từ thông dụng đã bị bỏ qua trong khi tìm kiếm');
DEFINE('_SEARCH_ANYWORDS','Bất kì từ nào');
DEFINE('_SEARCH_ALLWORDS','Mọi từ');
DEFINE('_SEARCH_PHRASE','Chính xác cả cụm từ');
DEFINE('_SEARCH_NEWEST','Mới nhất trước');
DEFINE('_SEARCH_OLDEST','Cũ nhất trước');
DEFINE('_SEARCH_POPULAR','Phổ biến nhất');
DEFINE('_SEARCH_ALPHABETICAL','Thứ tự ABC');
DEFINE('_SEARCH_CATEGORY','Phần/Chuyên mục');
DEFINE('_SEARCH_MESSAGE','Độ dài hợp lệ của từ khoá là từ 3 đến 20 kí tự');
DEFINE('_SEARCH_ARCHIVED','Lưu trữ');
DEFINE('_SEARCH_CATBLOG','Blog chuyên mục');
DEFINE('_SEARCH_CATLIST','Danh sách chuyên mục');
DEFINE('_SEARCH_NEWSFEEDS','Newsfeeds');
DEFINE('_SEARCH_SECLIST','Danh sách các phần');
DEFINE('_SEARCH_SECBLOG','Blog các phần');


/** templates/*.php */
DEFINE('_ISO','charset=utf-8');
DEFINE('_DATE_FORMAT','Y/m/d');  //Uses PHP's DATE Command Format - Depreciated
/**
* Modify this line to reflect how you want the date to appear in your site
*
*e.g. DEFINE("_DATE_FORMAT_LC","%A, %d %B %Y %H:%M"); //Uses PHP's strftime Command Format
*/
DEFINE('_DATE_FORMAT_LC',"%d/%m/%Y"); //Uses PHP's strftime Command Format
DEFINE('_DATE_FORMAT_LC2',"%d/%m/%Y %H:%M");
DEFINE('_SEARCH_BOX','tìm kiếm...');
DEFINE('_NEWSFLASH_BOX','Tin nhanh!');
DEFINE('_MAINMENU_BOX','Mục lục');

/** classes/html/usermenu.php */
DEFINE('_UMENU_TITLE','Người dùng');
DEFINE('_HI','Xin chào, ');

/** user.php */
DEFINE('_SAVE_ERR','Hãy điền đủ các ô.');
DEFINE('_THANK_SUB','Xin cảm ơn. Thông tin của bạn sẽ được kiểm duyệt trước khi được công bố.');
DEFINE('_THANK_SUB_PUB','Cám ơn bạn về bài viết.');
DEFINE('_UP_SIZE','Bạn không thể tải lên tập tin lớn hơn 15kb.');
DEFINE('_UP_EXISTS','Hình ảnh $userfile_name đã có trước. Hãy đổi tên tập tin và thử lại.');
DEFINE('_UP_COPY_FAIL','Không sao chép được');
DEFINE('_UP_TYPE_WARN','Bạn có thể tải lên một ảnh gif, hoặc jpg.');
DEFINE('_MAIL_SUB','Người dùng đã gửi');
DEFINE('_MAIL_MSG','Xin chào $adminName,\n\n\nMột người dùng đã gửi $type:\n [ $title ]\n đã được gửi từ:\n [ $author ]\n'
.' cho $mosConfig_live_site.\n\n\n\n'
.'Hãy tới $mosConfig_live_site/administrator để xem và kiểm duyệt $type.\n\n'
.'Xin đừng trả lời thư này\n');
DEFINE('_PASS_VERR1','Nếu bạn muốn đổi mật khẩu thì hãy nhập lại mật khẩu để xác nhận.');
DEFINE('_PASS_VERR2','Nếu bạn muốn đổi mật khẩu hãy đảm bảo là mật khẩu và phần xác nhận phải khớp với nhau.');
DEFINE('_UNAME_INUSE','Tên người dùng này đã có người sử dụng.');
DEFINE('_UPDATE','Cập nhật');
DEFINE('_USER_DETAILS_SAVE','Các thiết lập của bạn đã được lưu lại.');
DEFINE('_USER_LOGIN','Người dùng đăng nhập');

/** components/com_user */
DEFINE('_EDIT_TITLE','Sửa thông tin về bạn');
DEFINE('_YOUR_NAME','Tên của bạn:');
DEFINE('_EMAIL','email:');
DEFINE('_UNAME','Tên người dùng:');
DEFINE('_PASS','Mật khẩu:');
DEFINE('_VPASS','Xác nhận mật khẩu:');
DEFINE('_SUBMIT_SUCCESS','Gửi thành công!');
DEFINE('_SUBMIT_SUCCESS_DESC','Nội dung bạn gửi đã được chuyển tới người quản trị. Nó sẽ được kiểm duyệt trước khi có thể được công bố.');
DEFINE('_WELCOME','Chào mừng!');
DEFINE('_WELCOME_DESC','Chào mừng bạn tới khu vực người dùng trên site của chúng tôi');
DEFINE('_CONF_CHECKED_IN','Checked out items have now been all checked in');
DEFINE('_CHECK_TABLE','Checking table');
DEFINE('_CHECKED_IN','Checked in');
DEFINE('_CHECKED_IN_ITEMS',' bài');
DEFINE('_PASS_MATCH','Mật khẩu không khớp');

/** components/com_banners */
DEFINE('_BNR_CLIENT_NAME','Bạn phải chọn tên cho khách hàng.');
DEFINE('_BNR_CONTACT','Bạn phải chọn địa chỉ liên lạc cho khách hàng.');
DEFINE('_BNR_VALID_EMAIL','Bạn phải chọn một địa chỉ email hợp lệ cho khách hàng.');
DEFINE('_BNR_CLIENT','Bạn phải chọn một khách hàng,');
DEFINE('_BNR_NAME','Bạn phải chọn tên cho banner.');
DEFINE('_BNR_IMAGE','Bạn phải chọn một hình ảnh cho banner.');
DEFINE('_BNR_URL','Bạn phải chọn một URL/mã tuỳ chọn cho banner.');

/** components/com_login */
DEFINE('_ALREADY_LOGIN','Bây giờ bạn đã đăng nhập!');
DEFINE('_LOGOUT','Nhấn vào đây để đăng xuất');
DEFINE('_LOGIN_TEXT','Use the login and password fields opposite to gain full access');
DEFINE('_LOGIN_SUCCESS','Bạn đã đăng nhập thành công');
DEFINE('_LOGOUT_SUCCESS','Bạn đã đăng xuất thành công');
DEFINE('_LOGIN_DESCRIPTION','Để truy cập khu vực cá nhân của site này, xin hãy đăng nhập');
DEFINE('_LOGOUT_DESCRIPTION','Hiện tại bạn đang đăng nhập vào khu vực cá nhân của site này');


/** components/com_weblinks */
DEFINE('_WEBLINKS_TITLE','Liên kết web');
DEFINE('_WEBLINKS_DESC','Dưới đây là danh sách các liên kết mà chúng tôi thấy là hữu ích <br />
.Từ danh sách dưới đây, hãy chọn một chủ đề và chọn một địa chỉ nào đó.');
DEFINE('_HEADER_TITLE_WEBLINKS','Liên kết web');
DEFINE('_SECTION','Khu vực:');
DEFINE('_SUBMIT_LINK','Gửi một địa chỉ');
DEFINE('_URL','URL:');
DEFINE('_URL_DESC','Miêu tả:');
DEFINE('_NAME','Tên:');
DEFINE('_WEBLINK_EXIST','Đã có một liên kết với tên đó, xin hãy thử lại.');
DEFINE('_WEBLINK_TITLE','Liên kết của bạn phải có tiêu đề.');

/** components/com_newfeeds */
DEFINE('_FEED_NAME','Feed Name');
DEFINE('_FEED_ARTICLES','# Bài viết');
DEFINE('_FEED_LINK','Feed Link');

/** whos_online.php - modify for Joomla 1.0.9 08-06-2006 by www.joomlaviet.org */
DEFINE('_WE_HAVE', 'Chúng ta có ');
DEFINE('_AND', ' và ');
DEFINE('_GUEST_COUNT','%s khách');
DEFINE('_GUESTS_COUNT','%s khách');
DEFINE('_MEMBER_COUNT','%s thành viên');
DEFINE('_MEMBERS_COUNT','%s thành viên');
DEFINE('_ONLINE',' trực tuyến');
DEFINE('_NONE','Không có ai trực tuyến');

/** modules/mod_banners */
DEFINE('_BANNER_ALT','Quảng cáo');

/** modules/mod_random_image */
DEFINE('_NO_IMAGES','Không có hình');

/** modules/mod_stats.php */
DEFINE('_TIME_STAT','Thời gian');
DEFINE('_MEMBERS_STAT','Thành viên');
DEFINE('_HITS_STAT','Lần xem');
DEFINE('_NEWS_STAT','Tin tức');
DEFINE('_LINKS_STAT','Liên kết web');
DEFINE('_VISITORS','Khách');

/** /adminstrator/components/com_menus/admin.menus.html.php */
DEFINE('_MAINMENU_HOME','* Mục đầu tiên trên trình đơn này [mục lục] là `Trang đầu` của website *');
DEFINE('_MAINMENU_DEL','* Bạn không thể `xoá` trình đơn này khi nó bắt buộc phải có cho các hoạt động của joomla *');
DEFINE('_MENU_GROUP','* Một số `Kiểu trình đơn` xuất hiện trong hơn một nhóm *');


/** administrators/components/com_users */
DEFINE('_NEW_USER_MESSAGE_SUBJECT', 'Thông tin về người dùng mới' );
DEFINE('_NEW_USER_MESSAGE', 'Xin chào %s,


Bạn đã được đưa vào danh sách người dùng của %s bởi chính người quản trị.

Email này có chưa tên người dùng và mật khẩu để bạn có thể đăng nhập vào %s

Tên người dùng - %s
Mật khẩu - %s


Xin đừng trả lời thư này vì nó được tự động tạo ra duy nhất vì mục đích thông tin');

/** administrators/components/com_massmail */
DEFINE('_MASSMAIL_MESSAGE', "Đây là một email từ '%s'

Thông điệp:
" );


/** includes/pdf.php */
DEFINE('_PDF_GENERATED','Tạo bởi:');
DEFINE('_PDF_POWERED','Powered by Joomla!');

/** Change for Joomla 1.0.9 version - added date 2006-06-08 by www.joomlaviet.org */
/** Vietnam Language for Joomla 1.0.10 - release date: 2006-07-11 - fixed by thegioiphatminh@yahoo.com */

//Line  26: DEFINE('_VALID_AZ09_USER','Vui lòng nhập %s hợp lệ. Nhiều hơn %d ký tự và chỉ bao gồm 0-9,a-z,A-Z');
//Line  35: DEFINE('_CMN_APPLY','Chấp nhận');
//Line  80: DEFINE('_STATIC_CONTENT','Nội dung tĩnh');
//Line 146: DEFINE('_CONTACT_MORE_THAN','Bạn không thể nhập nhiều hơn 1 địa chỉ email.');
//Line 166: DEFINE('_CONTACT_ONE_EMAIL','Bạn không thể nhập nhiều hơn 1 địa chỉ email.');
//Line 229: DEFINE('_E_NO_IMAGE','Không có hình');
//Line 239: DEFINE('_E_CAPTION_POSITION','Vị trí tiêu đề');
//Line 240: DEFINE('_E_CAPTION_ALIGN','Canh hàng tiêu đề');
//Line 241: DEFINE('_E_CAPTION_WIDTH','Độ rộng tiêu đề');
//Line 242: DEFINE('_KEY_NOT_FOUND','Từ khoá không tìm thấy');
//Line 243: DEFINE('_NO_IMAGES','Không có hình ảnh');
//Line 434: DEFINE('_THANK_SUB_PUB','Cám ơn bạn về bài viết.');

/** Change for Joomla 1.0.12 version - added date 25-12-2006 by www.joomlaviet.org*/
//Line 21: DEFINE( '_SYSERR1', '...' );
//Line 22: DEFINE( '_SYSERR2', '...' );
//Line 23: DEFINE( '_SYSERR3', '...' );
//Line 99: DEFINE('_INSTALL_3PD_WARN', '...')
//Line 121: DEFINE('_SUBMIT_BUTTON','...');
//Line 298: DEFINE('_ALREADY_VOTE','...');
//Line 376: DEFINE('_REG_ACTIVATE_FAILURE', '...');
//Line 523: DEFINE('_BANNER_ALT','...');
?>