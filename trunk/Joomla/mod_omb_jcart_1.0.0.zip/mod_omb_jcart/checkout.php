<?php

// get Joomla url string
	$shopURL = $_SERVER['HTTP_REFERER'];
		
/* jcar loaded by AJAX as session need be created after CMS sessions loaded, or create a namespace instead if you prefer */
echo "<script type='text/javascript'>";
	echo "window.onload=function(){";
			echo "$.ajax({";
			echo "url : \"$jcartModDir/jcart/jcart-relay.php\?jcart_is_checkout=true\",";
			echo "success : function (data) {";
			echo "$(\"#target_2\").html(data);";
			echo "}";
		echo "});";
	echo "}";		
echo "</script>";
?> 

<div id="wrapper">
	<h2>jCart Demo Checkout</h2>

	<div id="content">
		<!-- jcart insert -->
			<div id="target_2">
				<img src="modules/mod_omb_jcart/images/ajax_loading.gif" alt="Loading.." height="16" width="16" align="left" border="0" />&nbsp;&nbsp;Cart Loading...
			 </div>
		
		<p><a href="<?php echo $shopURL; ?>">&larr; Continue shopping</a></p>

		<div class="clear"></div>
	</div>
</div>
