<?php
/*
* @version		$Id: mod_omb_jcart.php  2009-07-12
* @package		Joomla
* @copyright	Copyright (C) 2009 Brian Williford & Oh My Brain, inc. All rights reserved.
* @license		GNU/GPL, see LICENSE.php

* This program is free software; you can redistribute it and/or
* modify it under the terms of the GNU General Public License
* as published by the Free Software Foundation; either version 2
* of the License, or (at your option) any later version.

* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.

* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

* The "GNU General Public License" (GPL) is available at
* http://www.gnu.org/copyleft/gpl.html.

* mod_omb_jcart.php - Version 1.0.0
* Last modified Brian Williford :: 2009.07.18
*/

// no direct access
	defined('_JEXEC') or die('Restricted access');

// system vars
	$config					= & JFactory::getConfig();
	$jcartIncludeDir		= dirname(__FILE__); // for file in includes
	$mosConfig_live_site	= JURI::base(); // for http calls, like images
	$jcartModDir			= $mosConfig_live_site.'modules/mod_omb_jcart';
		// echo $jcartModDir;
		
	//$joomlaMenuURL = $_SERVER['HTTP_REFERER'];
		//echo "Referer: " . $joomlaMenuURL . "<br />";
		
	//$option = strtolower(strval(JRequest::getCmd('option')));
		//echo "option : " . $option  . "<br />";
	
	if($mainframe->getCfg('sef_rewrite')) {
		$sef = 1;
	} else {
		$sef = 0;	
	}

		 
// get query string out of sef
	$query_string = http_build_query(JRequest::get( 'get' ));
	$joomlaMenuURL = "index.php?" . $query_string;
		// echo $joomlaMenuURL . "<br />";	
	
// Include the monster functions only once
	require_once (dirname(__FILE__).DS.'helper.php');
		
/* set up some other params */
	$include_mode = $params->get( 'include_mode', 1 );
	$mooletsTargetDiv = $params->get( 'mooletsTargetDiv', 1 );

// module params
	$include_mode = $params->get('include_mode');
	$currency_symbol = $params->get('currency_symbol');

	$product_name_1 = $params->get('product_name_1');
	$product_price_1 = $params->get('product_price_1');
	$product_name_2 = $params->get('product_name_2');
	$product_price_2 = $params->get('product_price_2');
	$product_name_3 = $params->get('product_name_3');
	$product_price_3 = $params->get('product_price_3');
	$product_name_4 = $params->get('product_name_4');
	$product_price_4 = $params->get('product_price_4');
	$product_name_5 = $params->get('product_name_5');
	$product_price_5 = $params->get('product_price_5');
	$product_name_6 = $params->get('product_name_6');
	$product_price_6 = $params->get('product_price_6');
	$product_name_7 = $params->get('product_name_7');
	$product_price_7 = $params->get('product_price_7');
	$product_name_8 = $params->get('product_name_8');
	$product_price_8 = $params->get('product_price_8');
	$product_name_9 = $params->get('product_name_9');
	$product_price_9 = $params->get('product_price_9');
	$product_name_10 = $params->get('product_name_10');
	$product_price_10 = $params->get('product_price_10');
	$product_name_11 = $params->get('product_name_11');
	$product_price_11 = $params->get('product_price_11');
	$product_name_12 = $params->get('product_name_12');
	$product_price_12 = $params->get('product_price_12');
	
// load in css mootools and
	$doc = &JFactory::getDocument();
	$doc->addStyleSheet('modules/mod_omb_jcart/mod_omb_jcart.css');
	
	if ($include_mode > 0) {
		$doc->addScript("modules/mod_omb_jcart/jcart/jquery-1.3.2.min.js");
	}
	$doc->addScript("modules/mod_omb_jcart/jcart/jcart-javascript.min.php");
	
	
		
/* jcar loaded by AJAX as session need be created after CMS sessions loaded, or create a namespace instead if you prefer */
if (isset($_GET['action'])) {   
	//echo "what is this";
} else {
	echo "<script type='text/javascript'>";
		echo "window.onload=function(){";
			//echo "alert('The variable has the following value: $testVar');";
				echo "$.ajax({";
				echo "url : \"$jcartModDir/jcart/jcart-relay.php?sef=$sef\",";
				echo "success : function (data) {";
				echo "$(\"#jcart_target\").html(data);";
				echo "}";
			echo "});";
		echo "}";		
	echo "</script>";
}


// load checkout
	if (isset($_GET['action'])) {   		
   		if ($_GET['action'] == "checkout") {
   			include("checkout.php");
   		} else if ($_GET['action'] == "gateway") {
   			 include("jcart/jcart-gateway.php");
   		}
	
	// load cart
	} else { ?> 

	<div id="cart_wrapper">
		<div id="cart_items">
			<?php
				// here is the product display loop. Stylize as desired
				$counter = 0;
				for ( $counter = 1; $counter <= 12; $counter += 1) {
					
					$prodName = "product_name_".$counter;
					$prodNameVal = $$prodName;
					//
					$prodPrice = "product_price_".$counter;
					$prodPriceVal = $$prodPrice;
					// echo $prodNameVal . " - " . $prodPriceVal . "<br />";
					
					if($prodNameVal !=''){				
						echo "<form method=\"post\" action=\"\" class=\"jcart\">\n";
							echo "<fieldset>\n";
								echo "<input type=\"hidden\" name=\"my-item-id\" value=\"$counter\" />\n";
								echo "<input type=\"hidden\" name=\"my-item-name\" value=\"$prodNameVal\" />\n";
								echo "<input type=\"hidden\" name=\"my-item-price\" value=\"$prodPriceVal\" />\n";
								//
								echo "<ul>\n";
								echo "<li><strong>".$prodNameVal."</strong></li>\n";
								echo "<li>Price: ".$currency_symbol.$prodPriceVal."</li>\n";
								echo "<li><label>Qty: <input type=\"text\" name=\"my-item-qty\" value=\"1\" size=\"3\" /></label></li>\n";
								echo "</ul>\n";
								echo "<input type=\"submit\" name=\"my-add-button\" value=\"add to cart\" class=\"jcart_button\" />\n";						
								// echo $counter;
							echo "</fieldset>\n";
						echo "</form>\n";
					}
				}
				
			?>
		</div>

		<div id="cart_sidebar">
			<!-- jcart insert -->
			<div id="jcart_target">
				<img src="modules/mod_omb_jcart/images/ajax_loading.gif" alt="Loading.." height="16" width="16" align="left" border="0" />&nbsp;&nbsp;Cart Loading...
			 </div>
		</div>


	</div>



<?php 	} ?> 